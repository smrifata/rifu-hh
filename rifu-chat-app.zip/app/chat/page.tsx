"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Send, LogOut, Users, MessageSquare, Settings, Search } from "lucide-react"
import ChatMessage from "@/components/chat-message"
import MobileHeader from "@/components/mobile-header"
import { useMobile } from "@/hooks/use-mobile"

// Mock data for contacts and messages
const CONTACTS = [
  { id: "user1", name: "Sarah Johnson", lastSeen: "2 min ago", avatar: "/placeholder.svg?height=40&width=40" },
  { id: "user2", name: "Alex Chen", lastSeen: "1 hour ago", avatar: "/placeholder.svg?height=40&width=40" },
  { id: "user3", name: "Miguel Rodriguez", lastSeen: "3 hours ago", avatar: "/placeholder.svg?height=40&width=40" },
  { id: "user4", name: "Emma Wilson", lastSeen: "5 hours ago", avatar: "/placeholder.svg?height=40&width=40" },
  { id: "user5", name: "Jamal Ahmed", lastSeen: "1 day ago", avatar: "/placeholder.svg?height=40&width=40" },
]

const INITIAL_MESSAGES = {
  user1: [
    { id: 1, sender: "user1", text: "Hey there! How are you doing today?", timestamp: "10:30 AM" },
    { id: 2, sender: "me", text: "I'm good, thanks for asking! Just working on a new project.", timestamp: "10:32 AM" },
    { id: 3, sender: "user1", text: "That sounds interesting! What kind of project is it?", timestamp: "10:33 AM" },
    {
      id: 4,
      sender: "me",
      text: "It's a chat application called Rifu. I'm really excited about it!",
      timestamp: "10:35 AM",
    },
    {
      id: 5,
      sender: "user1",
      text: "That sounds amazing! I'd love to hear more about it when you have time.",
      timestamp: "10:36 AM",
    },
  ],
  user2: [
    { id: 1, sender: "user2", text: "Did you see the game last night?", timestamp: "Yesterday" },
    { id: 2, sender: "me", text: "Yes! It was incredible!", timestamp: "Yesterday" },
  ],
  user3: [
    { id: 1, sender: "me", text: "Hey Miguel, are we still meeting tomorrow?", timestamp: "2 days ago" },
    { id: 2, sender: "user3", text: "Yes, 2pm at the coffee shop works for me.", timestamp: "2 days ago" },
  ],
}

export default function ChatPage() {
  const router = useRouter()
  const isMobile = useMobile()
  const [user, setUser] = useState<{ id: string; name: string } | null>(null)
  const [activeTab, setActiveTab] = useState("chats")
  const [selectedContact, setSelectedContact] = useState(CONTACTS[0])
  const [messages, setMessages] = useState(INITIAL_MESSAGES)
  const [newMessage, setNewMessage] = useState("")
  const [showSidebar, setShowSidebar] = useState(!isMobile)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // Check if user is logged in
    const storedUser = localStorage.getItem("rifuUser")
    if (!storedUser) {
      router.push("/login")
      return
    }

    setUser(JSON.parse(storedUser))
  }, [router])

  useEffect(() => {
    // Scroll to bottom of messages
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages, selectedContact])

  useEffect(() => {
    // Handle sidebar visibility based on screen size
    if (!isMobile) {
      setShowSidebar(true)
    } else {
      setShowSidebar(false)
    }
  }, [isMobile])

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault()

    if (!newMessage.trim()) return

    const newMsg = {
      id: Date.now(),
      sender: "me",
      text: newMessage,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    }

    setMessages((prev) => ({
      ...prev,
      [selectedContact.id]: [...(prev[selectedContact.id] || []), newMsg],
    }))

    setNewMessage("")

    // Simulate reply after 1-3 seconds
    if (Math.random() > 0.3) {
      const replyDelay = 1000 + Math.random() * 2000
      setTimeout(() => {
        const replies = [
          "That's interesting!",
          "I see what you mean.",
          "Thanks for sharing that.",
          "I'll think about it and get back to you.",
          "That makes sense!",
          "I agree with you.",
          "Could you tell me more about that?",
        ]

        const replyMsg = {
          id: Date.now(),
          sender: selectedContact.id,
          text: replies[Math.floor(Math.random() * replies.length)],
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        }

        setMessages((prev) => ({
          ...prev,
          [selectedContact.id]: [...(prev[selectedContact.id] || []), replyMsg],
        }))
      }, replyDelay)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem("rifuUser")
    router.push("/login")
  }

  const toggleSidebar = () => {
    setShowSidebar(!showSidebar)
  }

  if (!user) {
    return null // Loading state or redirect handled by useEffect
  }

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Mobile Header */}
      {isMobile && (
        <MobileHeader toggleSidebar={toggleSidebar} selectedContact={selectedContact} showSidebar={showSidebar} />
      )}

      {/* Sidebar */}
      {showSidebar && (
        <div
          className={`${isMobile ? "absolute z-10 h-full" : "relative"} w-80 bg-white border-r border-gray-200 flex flex-col`}
        >
          <div className="p-4 border-b border-gray-200 flex items-center justify-between">
            <h1 className="text-xl font-bold text-rose-600">Rifu</h1>
            <Button variant="ghost" size="icon" onClick={handleLogout}>
              <LogOut className="h-5 w-5 text-gray-500" />
            </Button>
          </div>

          <div className="p-3">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-400" />
              <Input placeholder="Search..." className="pl-8 bg-gray-100 border-0" />
            </div>
          </div>

          <Tabs defaultValue="chats" className="flex-1 flex flex-col">
            <TabsList className="grid grid-cols-3 mx-3">
              <TabsTrigger value="chats" onClick={() => setActiveTab("chats")}>
                <MessageSquare className="h-4 w-4 mr-1" />
                Chats
              </TabsTrigger>
              <TabsTrigger value="contacts" onClick={() => setActiveTab("contacts")}>
                <Users className="h-4 w-4 mr-1" />
                Contacts
              </TabsTrigger>
              <TabsTrigger value="settings" onClick={() => setActiveTab("settings")}>
                <Settings className="h-4 w-4 mr-1" />
                Settings
              </TabsTrigger>
            </TabsList>

            <TabsContent value="chats" className="flex-1 overflow-hidden">
              <ScrollArea className="h-full">
                <div className="p-3 space-y-2">
                  {CONTACTS.map((contact) => (
                    <div
                      key={contact.id}
                      className={`flex items-center p-3 rounded-lg cursor-pointer transition-colors ${
                        selectedContact.id === contact.id ? "bg-rose-50 text-rose-600" : "hover:bg-gray-100"
                      }`}
                      onClick={() => {
                        setSelectedContact(contact)
                        if (isMobile) setShowSidebar(false)
                      }}
                    >
                      <Avatar className="h-10 w-10 mr-3">
                        <AvatarImage src={contact.avatar || "/placeholder.svg"} alt={contact.name} />
                        <AvatarFallback>{contact.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-baseline">
                          <h3 className="font-medium truncate">{contact.name}</h3>
                          <span className="text-xs text-gray-500 ml-2 whitespace-nowrap">{contact.lastSeen}</span>
                        </div>
                        <p className="text-sm text-gray-500 truncate">
                          {messages[contact.id]?.length > 0
                            ? `${messages[contact.id][messages[contact.id].length - 1].sender === "me" ? "You: " : ""}${
                                messages[contact.id][messages[contact.id].length - 1].text
                              }`
                            : "Start a conversation"}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="contacts" className="flex-1 overflow-hidden">
              <ScrollArea className="h-full">
                <div className="p-3 space-y-2">
                  {CONTACTS.map((contact) => (
                    <div
                      key={contact.id}
                      className="flex items-center p-3 rounded-lg cursor-pointer hover:bg-gray-100"
                      onClick={() => {
                        setSelectedContact(contact)
                        setActiveTab("chats")
                        if (isMobile) setShowSidebar(false)
                      }}
                    >
                      <Avatar className="h-10 w-10 mr-3">
                        <AvatarImage src={contact.avatar || "/placeholder.svg"} alt={contact.name} />
                        <AvatarFallback>{contact.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="font-medium">{contact.name}</h3>
                        <p className="text-sm text-gray-500">{contact.lastSeen}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="settings" className="flex-1 p-4">
              <h2 className="text-lg font-medium mb-4">Settings</h2>
              <div className="space-y-4">
                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Account</h3>
                  <div className="bg-gray-100 p-3 rounded-lg">
                    <p className="text-sm font-medium">{user.name}</p>
                    <p className="text-xs text-gray-500">User ID: {user.id}</p>
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Appearance</h3>
                  <div className="flex items-center justify-between bg-gray-100 p-3 rounded-lg">
                    <span className="text-sm">Dark Mode</span>
                    <Button variant="outline" size="sm">
                      Enable
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Notifications</h3>
                  <div className="flex items-center justify-between bg-gray-100 p-3 rounded-lg">
                    <span className="text-sm">Push Notifications</span>
                    <Button variant="outline" size="sm">
                      Enable
                    </Button>
                  </div>
                </div>

                <Button variant="destructive" className="w-full mt-6" onClick={handleLogout}>
                  Log Out
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      )}

      {/* Chat Area */}
      <div className="flex-1 flex flex-col">
        {/* Chat Header - Desktop */}
        {!isMobile && (
          <div className="p-4 border-b border-gray-200 flex items-center bg-white">
            <Avatar className="h-10 w-10 mr-3">
              <AvatarImage src={selectedContact.avatar || "/placeholder.svg"} alt={selectedContact.name} />
              <AvatarFallback>{selectedContact.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div>
              <h2 className="font-medium">{selectedContact.name}</h2>
              <p className="text-xs text-gray-500">{selectedContact.lastSeen}</p>
            </div>
          </div>
        )}

        {/* Messages */}
        <ScrollArea className="flex-1 p-4 bg-gray-50">
          <div className="space-y-4 max-w-3xl mx-auto">
            {messages[selectedContact.id]?.map((message) => (
              <ChatMessage
                key={message.id}
                message={message}
                isMe={message.sender === "me"}
                contactName={selectedContact.name}
              />
            ))}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>

        {/* Message Input */}
        <div className="p-4 border-t border-gray-200 bg-white">
          <form onSubmit={handleSendMessage} className="flex space-x-2 max-w-3xl mx-auto">
            <Input
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Type a message..."
              className="flex-1"
            />
            <Button type="submit" size="icon" className="bg-rose-500 hover:bg-rose-600">
              <Send className="h-4 w-4" />
            </Button>
          </form>
        </div>
      </div>
    </div>
  )
}
